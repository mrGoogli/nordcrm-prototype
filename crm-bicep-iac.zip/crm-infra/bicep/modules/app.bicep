// ============================================================
// MODULE: app.bicep
// Azure Container Apps Environment, Container Apps (microservices),
// Azure AI Search, Azure OpenAI (EU endpoint)
// ============================================================

param prefix          string
param location        string
param cosmosAccountId string
param serviceBusId    string
param keyVaultId      string
param staccApiUrl     string
param tags            object

// ── LOG ANALYTICS (shared with observability module) ────────
resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'log-${prefix}'
  location: location
  tags: tags
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 365        // DORA: 1-year minimum log retention
    features: {
      enableLogAccessUsingOnlyResourcePermissions: true
    }
    publicNetworkAccessForIngestion: 'Enabled'
    publicNetworkAccessForQuery:     'Disabled'
  }
}

// ── CONTAINER APPS ENVIRONMENT ──────────────────────────────
resource acaEnv 'Microsoft.App/managedEnvironments@2023-11-02-preview' = {
  name: 'acaenv-${prefix}'
  location: location
  tags: tags
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logAnalytics.properties.customerId
        sharedKey:  logAnalytics.listKeys().primarySharedKey
      }
    }
    zoneRedundant: true    // DORA: zone redundancy
    workloadProfiles: [
      { name: 'Consumption', workloadProfileType: 'Consumption' }
      { name: 'D4',          workloadProfileType: 'D4',  minimumCount: 1, maximumCount: 5 }
    ]
  }
}

// ── MICROSERVICES — CONTAINER APPS ───────────────────────────
var services = [
  {
    name: 'contact-service'
    image: 'nordcrm/contact-service:latest'
    cpu: '0.5'
    memory: '1Gi'
    minReplicas: 2
    maxReplicas: 10
    port: 8080
  }
  {
    name: 'deal-service'
    image: 'nordcrm/deal-service:latest'
    cpu: '0.5'
    memory: '1Gi'
    minReplicas: 2
    maxReplicas: 10
    port: 8080
  }
  {
    name: 'support-service'
    image: 'nordcrm/support-service:latest'
    cpu: '0.5'
    memory: '1Gi'
    minReplicas: 1
    maxReplicas: 8
    port: 8080
  }
  {
    name: 'marketing-service'
    image: 'nordcrm/marketing-service:latest'
    cpu: '0.5'
    memory: '1Gi'
    minReplicas: 1
    maxReplicas: 6
    port: 8080
  }
  {
    name: 'stacc-connector'
    image: 'nordcrm/stacc-connector:latest'
    cpu: '0.25'
    memory: '0.5Gi'
    minReplicas: 1
    maxReplicas: 4
    port: 8080
  }
  {
    name: 'gdpr-service'
    image: 'nordcrm/gdpr-service:latest'
    cpu: '0.25'
    memory: '0.5Gi'
    minReplicas: 1
    maxReplicas: 3
    port: 8080
  }
  {
    name: 'analytics-service'
    image: 'nordcrm/analytics-service:latest'
    cpu: '1.0'
    memory: '2Gi'
    minReplicas: 1
    maxReplicas: 6
    port: 8080
  }
]

resource containerApp 'Microsoft.App/containerApps@2023-11-02-preview' = [for svc in services: {
  name: 'ca-${svc.name}'
  location: location
  tags: union(tags, { Service: svc.name })
  identity: { type: 'SystemAssigned' }
  properties: {
    environmentId: acaEnv.id
    workloadProfileName: 'Consumption'
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: {
        external: false          // Internal only — API Management is the entry point
        targetPort: svc.port
        transport: 'http'
        allowInsecure: false
      }
      secrets: [
        {
          name:        'cosmos-connection'
          keyVaultUrl: '${reference(keyVaultId, '2023-07-01').vaultUri}secrets/cosmos-connection-string'
          identity:    'system'
        }
        {
          name:        'servicebus-connection'
          keyVaultUrl: '${reference(keyVaultId, '2023-07-01').vaultUri}secrets/servicebus-connection-string'
          identity:    'system'
        }
        {
          name:        'stacc-api-key'
          keyVaultUrl: '${reference(keyVaultId, '2023-07-01').vaultUri}secrets/stacc-api-key'
          identity:    'system'
        }
      ]
    }
    template: {
      containers: [
        {
          name:  svc.name
          image: svc.image
          resources: { cpu: json(svc.cpu), memory: svc.memory }
          env: [
            { name: 'AZURE_COSMOS_CONNECTION_STRING', secretRef: 'cosmos-connection' }
            { name: 'AZURE_SERVICEBUS_CONNECTION',    secretRef: 'servicebus-connection' }
            { name: 'STACC_API_KEY',                  secretRef: 'stacc-api-key' }
            { name: 'STACC_API_URL',                  value: staccApiUrl }
            { name: 'AZURE_KEYVAULT_URI',             value: reference(keyVaultId, '2023-07-01').vaultUri }
            { name: 'ASPNETCORE_ENVIRONMENT',         value: 'Production' }
            { name: 'DATA_REGION',                    value: 'EU_NORTH' }
          ]
          probes: [
            {
              type: 'Liveness'
              httpGet: { path: '/health', port: svc.port, scheme: 'HTTP' }
              initialDelaySeconds: 15
              periodSeconds: 30
            }
            {
              type: 'Readiness'
              httpGet: { path: '/ready', port: svc.port, scheme: 'HTTP' }
              initialDelaySeconds: 5
              periodSeconds: 10
            }
          ]
        }
      ]
      scale: {
        minReplicas: svc.minReplicas
        maxReplicas: svc.maxReplicas
        rules: [
          {
            name: 'http-scale'
            http: { metadata: { concurrentRequests: '100' } }
          }
        ]
      }
    }
  }
}]

// ── AZURE AI SEARCH ──────────────────────────────────────────
resource aiSearch 'Microsoft.Search/searchServices@2023-11-01' = {
  name: 'srch-${prefix}'
  location: location    // EU North — data residency (GDPR)
  tags: tags
  sku: { name: 'standard' }
  identity: { type: 'SystemAssigned' }
  properties: {
    replicaCount:   2   // HA for production
    partitionCount: 1
    publicNetworkAccess: 'disabled'
    authOptions: {
      aadOrApiKey: { aadAuthFailureMode: 'http401WithBearerChallenge' }
    }
    encryptionWithCmk: {
      enforcement: 'Enabled'   // CMK required (GDPR)
    }
  }
}

// ── AZURE OPENAI (EU endpoint — data residency) ──────────────
// NOTE: Deployed to Sweden Central (nearest EU OpenAI region to Denmark)
resource openai 'Microsoft.CognitiveServices/accounts@2023-10-01-preview' = {
  name: 'oai-${prefix}'
  location: 'swedencentral'   // EU OpenAI endpoint (data stays in EU)
  tags: tags
  kind: 'OpenAI'
  sku: { name: 'S0' }
  identity: { type: 'SystemAssigned' }
  properties: {
    publicNetworkAccess: 'Disabled'
    networkAcls: {
      defaultAction: 'Deny'
      bypass: 'AzureServices'
    }
    customSubDomainName: 'oai-${prefix}'
    // No training on customer prompts (GDPR — data minimisation)
    // Configure via Azure OpenAI Studio: disable fine-tuning on customer data
  }
}

// GPT-4o deployment
resource gpt4oDeployment 'Microsoft.CognitiveServices/accounts/deployments@2023-10-01-preview' = {
  parent: openai
  name: 'gpt-4o'
  sku: { name: 'Standard', capacity: 40 }  // 40K TPM
  properties: {
    model: {
      format: 'OpenAI'
      name:   'gpt-4o'
    }
    raiPolicyName: 'Microsoft.Default'
  }
}

// API Management reference (for routing)
resource apim 'Microsoft.ApiManagement/service@2023-05-01-preview' existing = {
  name: 'apim-${prefix}'
}

// ── OUTPUTS ──────────────────────────────────────────────────
output containerAppEnvId  string = acaEnv.id
output apiManagementUrl   string = 'https://${apim.properties.gatewayUrl}'
output searchServiceName  string = aiSearch.name
output openAiEndpoint     string = openai.properties.endpoint
output logAnalyticsId     string = logAnalytics.id
