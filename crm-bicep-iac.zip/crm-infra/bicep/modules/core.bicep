// ============================================================
// MODULE: core.bicep
// Key Vault (CMK), Service Bus, Redis Cache,
// Blob Storage, Azure API Management, Entra ID RBAC
// ============================================================

param prefix          string
param location        string
param drLocation      string
param tenantId        string
param adminGroupObjectId string
param alertEmail      string
param tags            object

// ── KEY VAULT (CMK for GDPR field-level encryption) ─────────
resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' = {
  name: 'kv-${prefix}'
  location: location
  tags: tags
  properties: {
    tenantId:               tenantId
    sku: { family: 'A', name: 'premium' }  // premium = HSM-backed keys (DORA requirement)
    enableSoftDelete:       true
    softDeleteRetentionInDays: 90          // GDPR: recover deleted keys
    enablePurgeProtection:  true           // DORA: immutable key lifecycle
    enableRbacAuthorization: true          // Use RBAC, not access policies
    publicNetworkAccess:    'Disabled'     // Private endpoint only
    networkAcls: {
      defaultAction: 'Deny'
      bypass:        'AzureServices'
    }
  }
}

// Admin group → Key Vault Administrator
resource kvAdminRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(keyVault.id, adminGroupObjectId, 'KeyVaultAdministrator')
  scope: keyVault
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', '00482a5a-887f-4fb3-b363-3b7fe8e74483')
    principalId:      adminGroupObjectId
    principalType:    'Group'
  }
}

// ── SERVICE BUS (async events between microservices + Stacc webhooks) ──
resource serviceBusNs 'Microsoft.ServiceBus/namespaces@2023-01-01-preview' = {
  name: 'sb-${prefix}'
  location: location
  tags: tags
  sku: { name: 'Premium', tier: 'Premium', capacity: 1 }
  properties: {
    minimumTlsVersion:    '1.2'
    publicNetworkAccess:  'Disabled'  // Private endpoint only
    zoneRedundant:        true        // DORA: resilience
  }
}

// Topics for domain events
var sbTopics = [
  'crm.deals.stage-changed'
  'crm.contacts.consent-changed'
  'crm.contacts.erasure-requested'
  'crm.incidents.dora'
  'stacc.webhooks.inbound'
  'm365.sync.trigger'
]

resource sbTopic 'Microsoft.ServiceBus/namespaces/topics@2023-01-01-preview' = [for t in sbTopics: {
  parent: serviceBusNs
  name: t
  properties: {
    defaultMessageTimeToLive:      'P14D'   // 14 days retention
    requiresDuplicateDetection:    true
    duplicateDetectionHistoryTimeWindow: 'PT10M'
    enablePartitioning:            false    // Premium: no partitioning needed
  }
}]

// Dead-letter queue subscription on DORA incidents
resource sbDoraSubscription 'Microsoft.ServiceBus/namespaces/topics/subscriptions@2023-01-01-preview' = {
  parent: sbTopic[3]  // crm.incidents.dora
  name:   'finanstilsynet-notifier'
  properties: {
    deadLetteringOnMessageExpiration: true
    maxDeliveryCount: 10
    lockDuration: 'PT5M'
  }
}

// ── REDIS CACHE (sessions, hot data) ────────────────────────
resource redis 'Microsoft.Cache/redis@2023-08-01' = {
  name: 'redis-${prefix}'
  location: location
  tags: tags
  properties: {
    sku: { name: 'Premium', family: 'P', capacity: 1 }
    enableNonSslPort:   false
    minimumTlsVersion:  '1.2'
    publicNetworkAccess: 'Disabled'
    redisConfiguration: {
      'maxmemory-policy': 'allkeys-lru'
      'rdb-backup-enabled': 'true'
      'rdb-backup-frequency': '60'       // DORA: backup every 60 min
    }
  }
}

// ── BLOB STORAGE (documents, attachments, audit archive) ─────
resource storageAccount 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: replace('st${prefix}', '-', '')  // Storage names: alphanumeric only
  location: location
  tags: tags
  kind: 'StorageV2'
  sku: { name: 'Standard_ZRS' }         // Zone-redundant storage (DORA)
  properties: {
    minimumTlsVersion:          'TLS1_2'
    allowBlobPublicAccess:      false
    supportsHttpsTrafficOnly:   true
    publicNetworkAccess:        'Disabled'
    allowSharedKeyAccess:       false    // AAD auth only
    defaultToOAuthAuthentication: true
    encryption: {
      requireInfrastructureEncryption: true  // Double encryption for financial data
      keySource: 'Microsoft.Keyvault'
      keyvaultproperties: {
        keyname:     'storage-cmk'
        keyvaulturi: keyVault.properties.vaultUri
      }
      services: {
        blob:  { enabled: true, keyType: 'Account' }
        file:  { enabled: true, keyType: 'Account' }
        queue: { enabled: true, keyType: 'Account' }
        table: { enabled: true, keyType: 'Account' }
      }
    }
  }
}

// Blob containers
var containers = [
  { name: 'attachments',  immutable: false }
  { name: 'audit-export', immutable: true  }  // DORA: immutable audit archive
  { name: 'gdpr-exports', immutable: false }
  { name: 'pbi-reports',  immutable: false }
]

resource blobService 'Microsoft.Storage/storageAccounts/blobServices@2023-01-01' = {
  parent: storageAccount
  name: 'default'
  properties: {
    deleteRetentionPolicy: { enabled: true, days: 365 }  // GDPR + DORA retention
  }
}

resource container 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-01-01' = [for c in containers: {
  parent: blobService
  name: c.name
  properties: {
    publicAccess: 'None'
  }
}]

// Immutable policy on audit-export
resource auditImmutabilityPolicy 'Microsoft.Storage/storageAccounts/blobServices/containers/immutabilityPolicies@2023-01-01' = {
  parent: container[1]
  name: 'default'
  properties: {
    immutabilityPeriodSinceCreationInDays: 365  // DORA: 1-year immutable audit
    allowProtectedAppendWrites: false
  }
}

// ── API MANAGEMENT ───────────────────────────────────────────
resource apim 'Microsoft.ApiManagement/service@2023-05-01-preview' = {
  name: 'apim-${prefix}'
  location: location
  tags: tags
  sku: { name: 'Premium', capacity: 1 }
  identity: { type: 'SystemAssigned' }
  properties: {
    publisherEmail: alertEmail
    publisherName:  'NordCRM Platform'
    virtualNetworkType: 'Internal'       // Private VNET only (DORA + GDPR)
    customProperties: {
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Tls10':  'false'
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Tls11':  'false'
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Protocols.Ssl30':  'false'
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Backend.Protocols.Tls10': 'false'
      'Microsoft.WindowsAzure.ApiManagement.Gateway.Security.Backend.Protocols.Ssl30': 'false'
    }
  }
}

// ── VNET (private networking for all resources) ─────────────
resource vnet 'Microsoft.Network/virtualNetworks@2023-06-01' = {
  name: 'vnet-${prefix}'
  location: location
  tags: tags
  properties: {
    addressSpace: { addressPrefixes: ['10.0.0.0/16'] }
    subnets: [
      {
        name: 'snet-aca'
        properties: { addressPrefix: '10.0.1.0/24' }
      }
      {
        name: 'snet-apim'
        properties: { addressPrefix: '10.0.2.0/24' }
      }
      {
        name: 'snet-private-endpoints'
        properties: {
          addressPrefix: '10.0.3.0/24'
          privateEndpointNetworkPolicies: 'Disabled'
        }
      }
    ]
  }
}

// ── OUTPUTS ──────────────────────────────────────────────────
output keyVaultId    string = keyVault.id
output keyVaultUri   string = keyVault.properties.vaultUri
output serviceBusId  string = serviceBusNs.id
output serviceBusEndpoint string = '${serviceBusNs.name}.servicebus.windows.net'
output storageId     string = storageAccount.id
output apimId        string = apim.id
output vnetId        string = vnet.id
output acaSubnetId   string = vnet.properties.subnets[0].id
output apimSubnetId  string = vnet.properties.subnets[1].id
output peSubnetId    string = vnet.properties.subnets[2].id
