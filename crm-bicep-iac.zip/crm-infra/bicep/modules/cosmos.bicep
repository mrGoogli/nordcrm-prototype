// ============================================================
// MODULE: cosmos.bicep
// Azure Cosmos DB — NoSQL, All CRM Containers
// CMK Encryption · GDPR TTL · Geo-replication (DORA DR)
// ============================================================

param prefix      string
param location    string
param drLocation  string
param keyVaultId  string
param tags        object

// ── COSMOS ACCOUNT ───────────────────────────────────────────
resource cosmos 'Microsoft.DocumentDB/databaseAccounts@2023-11-15' = {
  name: 'cosmos-${prefix}'
  location: location
  tags: tags
  kind: 'GlobalDocumentDB'
  identity: { type: 'SystemAssigned' }
  properties: {
    databaseAccountOfferType: 'Standard'
    consistencyPolicy: {
      defaultConsistencyLevel: 'Session'  // Balance: consistency vs. latency
    }
    locations: [
      {
        locationName:     location
        failoverPriority: 0
        isZoneRedundant:  true  // Zone redundancy in primary (DORA)
      }
      {
        locationName:     drLocation
        failoverPriority: 1
        isZoneRedundant:  false  // DR replica (DORA: geo-redundancy)
      }
    ]
    enableAutomaticFailover:      true   // DORA: auto-failover
    enableMultipleWriteLocations: false  // Single write region (simpler conflict resolution)
    publicNetworkAccess:          'Disabled'
    networkAclBypass:             'AzureServices'
    isVirtualNetworkFilterEnabled: false
    // CMK encryption — keys in Key Vault (GDPR + DORA)
    keyVaultKeyUri: '${reference(keyVaultId, '2023-07-01').vaultUri}keys/cosmos-cmk'
    defaultIdentity:  'SystemAssignedIdentity'
    backupPolicy: {
      type: 'Continuous'
      continuousModeProperties: {
        tier: 'Continuous30Days'  // DORA: 30-day continuous backup
      }
    }
    capabilities: [
      { name: 'EnableServerless' }  // Serverless for dev/staging; remove for prod (use provisioned)
    ]
  }
}

// ── DATABASE ─────────────────────────────────────────────────
resource db 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2023-11-15' = {
  parent: cosmos
  name: 'nordcrm'
  properties: {
    resource: { id: 'nordcrm' }
  }
}

// ── CONTAINER DEFINITIONS ────────────────────────────────────
// Each container maps 1:1 to the database schema design.
// TTL=-1 means inherit; TTL>0 means default expiry in seconds.
// Partition key is always /tenantId for strict tenant isolation.

var containers = [
  // ── IDENTITY & TENANCY ──
  {
    name: 'tenants'
    partitionKey: '/id'
    ttl: -1         // No TTL — tenant records permanent
    uniqueKeys: ['/cvrNumber']
    indexes: []
  }
  {
    name: 'users'
    partitionKey: '/tenantId'
    ttl: -1
    uniqueKeys: ['/entraObjectId']
    indexes: [
      { paths: ['/tenantId/?', '/email/?'], order: 'ascending' }
    ]
  }
  // ── CORE CRM ──
  {
    name: 'contacts'
    partitionKey: '/tenantId'
    ttl: 31536000   // Default 1yr — overridden per tenant retention policy
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/type/?', '/createdAt/?'],   order: 'descending' }
      { paths: ['/tenantId/?', '/ownerId/?', '/updatedAt/?'], order: 'descending' }
      { paths: ['/tenantId/?', '/gdpr/retentionExpiresAt/?'], order: 'ascending'  }
      { paths: ['/tenantId/?', '/gdpr/marketingSuppressed/?'], order: 'ascending' }
    ]
  }
  {
    name: 'accounts'
    partitionKey: '/tenantId'
    ttl: -1
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/name/?'], order: 'ascending' }
      { paths: ['/tenantId/?', '/cvrNumber/?'], order: 'ascending' }
    ]
  }
  // ── SALES ──
  {
    name: 'deals'
    partitionKey: '/tenantId'
    ttl: -1
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/stage/?', '/expectedCloseDate/?'], order: 'ascending' }
      { paths: ['/tenantId/?', '/ownerId/?', '/stage/?'], order: 'ascending' }
      { paths: ['/tenantId/?', '/closedAt/?', '/valueOere/?'], order: 'descending' }
    ]
  }
  {
    name: 'activities'
    partitionKey: '/tenantId'
    ttl: 94608000   // 3-year TTL (GDPR: email metadata retention)
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/contactId/?', '/occurredAt/?'], order: 'descending' }
      { paths: ['/tenantId/?', '/dealId/?', '/occurredAt/?'],    order: 'descending' }
    ]
  }
  // ── SUPPORT ──
  {
    name: 'tickets'
    partitionKey: '/tenantId'
    ttl: -1   // Financial complaints: 5yr mandatory (Finanstilsynet)
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/status/?', '/priority/?', '/createdAt/?'], order: 'descending' }
      { paths: ['/tenantId/?', '/assignedTo/?', '/status/?'], order: 'ascending' }
      { paths: ['/tenantId/?', '/isComplaint/?', '/createdAt/?'], order: 'descending' }
    ]
  }
  {
    name: 'ticket_messages'
    partitionKey: '/tenantId'
    ttl: 94608000   // 3-year TTL
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/ticketId/?', '/sentAt/?'], order: 'descending' }
    ]
  }
  // ── MARKETING ──
  {
    name: 'campaigns'
    partitionKey: '/tenantId'
    ttl: -1
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/status/?', '/scheduledAt/?'], order: 'ascending' }
    ]
  }
  {
    name: 'lead_scores'
    partitionKey: '/tenantId'
    ttl: 157680000  // 5-year TTL (AI explainability retention)
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/contactId/?', '/scoredAt/?'], order: 'descending' }
    ]
  }
  // ── GDPR + COMPLIANCE ──
  {
    name: 'rights_requests'
    partitionKey: '/tenantId'
    ttl: -1         // NO TTL — GDPR compliance evidence retained indefinitely
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/status/?', '/dueDateAt/?'], order: 'ascending' }
      { paths: ['/tenantId/?', '/contactId/?'], order: 'ascending' }
    ]
  }
  {
    name: 'audit_log'
    partitionKey: '/tenantId'
    ttl: -1         // NO TTL — DORA immutable audit trail (1yr minimum enforced by policy)
    uniqueKeys: []
    indexes: [
      { paths: ['/tenantId/?', '/resourceId/?', '/timestamp/?'], order: 'descending' }
      { paths: ['/tenantId/?', '/sensitiveAccess/?', '/timestamp/?'], order: 'descending' }
      { paths: ['/tenantId/?', '/action/?', '/timestamp/?'], order: 'descending' }
    ]
  }
]

resource cosmosContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2023-11-15' = [for c in containers: {
  parent: db
  name: c.name
  properties: {
    resource: {
      id: c.name
      partitionKey: {
        paths: [c.partitionKey]
        kind: 'Hash'
        version: 2
      }
      defaultTtl: c.ttl
      uniqueKeyPolicy: {
        uniqueKeys: [for uk in c.uniqueKeys: { paths: [uk] }]
      }
      indexingPolicy: {
        indexingMode: 'consistent'
        automatic: true
        includedPaths: [{ path: '/*' }]
        excludedPaths: [
          { path: '/"_etag"/?' }
          { path: '/gdpr/consents/*' }        // Exclude consent arrays from index (large, query by parent)
          { path: '/staccSnapshot/amlFlags/*' } // Encrypted: no index on financial arrays
        ]
        compositeIndexes: [for idx in c.indexes: [
          {
            path: idx.paths[0]
            order: idx.order
          }
        ]]
      }
    }
  }
}]

// ── OUTPUTS ──────────────────────────────────────────────────
output cosmosAccountId   string = cosmos.id
output cosmosAccountName string = cosmos.name
output cosmosDatabaseName string = db.name
output cosmosEndpoint    string = cosmos.properties.documentEndpoint
