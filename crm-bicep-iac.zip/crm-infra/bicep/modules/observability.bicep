// ============================================================
// MODULE: observability.bicep
// Azure Monitor · Application Insights · Microsoft Sentinel
// DORA mandatory: incident detection, 4h notification trigger
// GDPR: 72h breach detection alert
// ============================================================

param prefix      string
param location    string
param alertEmail  string
param tags        object

// ── LOG ANALYTICS WORKSPACE (shared) ─────────────────────────
resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: 'log-${prefix}'
}

// ── APPLICATION INSIGHTS ─────────────────────────────────────
resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: 'appi-${prefix}'
  location: location
  tags: tags
  kind: 'web'
  properties: {
    Application_Type:             'web'
    WorkspaceResourceId:          logAnalytics.id
    publicNetworkAccessForIngestion: 'Enabled'
    publicNetworkAccessForQuery:     'Disabled'
    RetentionInDays:              365  // DORA: 1yr telemetry retention
    DisableIpMasking:             false  // GDPR: mask IPs
  }
}

// ── ACTION GROUP (alert notifications) ──────────────────────
resource alertGroup 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: 'ag-${prefix}-critical'
  location: 'global'
  tags: tags
  properties: {
    groupShortName: 'CRM-CRIT'
    enabled: true
    emailReceivers: [
      {
        name:                 'DPO-Alert'
        emailAddress:         alertEmail
        useCommonAlertSchema: true
      }
    ]
    // Add Teams webhook here for real-time incident notifications
    // webhookReceivers: [{ name: 'teams', serviceUri: '<teams-webhook-url>' }]
  }
}

// ── ALERT: 5xx Errors (DORA — ICT incident detection) ────────
resource alert5xx 'Microsoft.Insights/metricAlerts@2018-03-01' = {
  name: 'alert-5xx-${prefix}'
  location: 'global'
  tags: tags
  properties: {
    description: 'DORA: Elevated 5xx error rate — potential ICT incident. Evaluate for major incident classification.'
    severity: 0    // Critical
    enabled: true
    scopes:  [appInsights.id]
    evaluationFrequency:  'PT1M'
    windowSize:           'PT5M'
    criteria: {
      'odata.type': 'Microsoft.Azure.Monitor.SingleResourceMultipleMetricCriteria'
      allOf: [
        {
          name:            '5xx-rate'
          metricName:      'requests/failed'
          operator:        'GreaterThan'
          threshold:       10
          timeAggregation: 'Count'
          criterionType:   'StaticThresholdCriterion'
        }
      ]
    }
    actions: [{ actionGroupId: alertGroup.id }]
  }
}

// ── ALERT: DORA — Stacc Integration Down ────────────────────
resource alertStaccDown 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: 'alert-stacc-down-${prefix}'
  location: location
  tags: tags
  properties: {
    description: 'DORA Art.17: Stacc API circuit breaker open >15min — third-party ICT disruption. Initial report to Finanstilsynet due within 4h if classified as major.'
    severity: 1
    enabled: true
    scopes:  [logAnalytics.id]
    evaluationFrequency: 'PT5M'
    windowSize:          'PT15M'
    criteria: {
      allOf: [
        {
          query: '''
            AppTraces
            | where Message has "stacc-connector" and Message has "circuit-breaker-open"
            | summarize count() by bin(TimeGenerated, 1m)
            | where count_ > 0
          '''
          timeAggregation: 'Count'
          operator:        'GreaterThan'
          threshold:       0
          failingPeriods: { numberOfEvaluationPeriods: 3, minFailingPeriodsToAlert: 3 }
        }
      ]
    }
    actions: {
      actionGroups: [alertGroup.id]
      customProperties: {
        DORAArticle:  'Art.17'
        IncidentType: 'ThirdPartyDisruption'
        InitialReportDue: '+4h'
      }
    }
  }
}

// ── ALERT: GDPR — Potential Data Breach (72h clock) ─────────
resource alertDataBreach 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: 'alert-data-breach-${prefix}'
  location: location
  tags: tags
  properties: {
    description: 'GDPR Art.33: Potential personal data breach detected. Datatilsynet notification due within 72h of awareness.'
    severity: 0
    enabled: true
    scopes:  [logAnalytics.id]
    evaluationFrequency: 'PT5M'
    windowSize:          'PT10M'
    criteria: {
      allOf: [
        {
          query: '''
            AppTraces
            | where SeverityLevel >= 3
            | where Message has_any ("unauthorised-access", "data-breach", "pii-exfiltration", "bulk-export-anomaly")
            | summarize count() by bin(TimeGenerated, 5m)
          '''
          timeAggregation: 'Count'
          operator:        'GreaterThan'
          threshold:       0
          failingPeriods: { numberOfEvaluationPeriods: 1, minFailingPeriodsToAlert: 1 }
        }
      ]
    }
    actions: {
      actionGroups: [alertGroup.id]
      customProperties: {
        Regulation:       'GDPR-Art33'
        NotifyAuthority:  'Datatilsynet'
        Deadline:         '72h'
      }
    }
  }
}

// ── ALERT: DORA — M365 Graph API Down ────────────────────────
resource alertM365Down 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: 'alert-m365-down-${prefix}'
  location: location
  tags: tags
  properties: {
    description: 'DORA: Microsoft Graph API unavailable >10min — ICT dependency failure.'
    severity: 2
    enabled: true
    scopes:  [logAnalytics.id]
    evaluationFrequency: 'PT5M'
    windowSize:          'PT10M'
    criteria: {
      allOf: [
        {
          query: '''
            AppTraces
            | where Message has "m365-connector" and Message has "graph-api-timeout"
            | summarize count() by bin(TimeGenerated, 1m)
            | where count_ > 5
          '''
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: { numberOfEvaluationPeriods: 2, minFailingPeriodsToAlert: 2 }
        }
      ]
    }
    actions: { actionGroups: [alertGroup.id] }
  }
}

// ── ALERT: Rights Request Overdue (GDPR 30-day SLA) ─────────
resource alertRightsOverdue 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: 'alert-rights-overdue-${prefix}'
  location: location
  tags: tags
  properties: {
    description: 'GDPR Art.12: Data subject rights request approaching 30-day deadline. DPO action required.'
    severity: 2
    enabled: true
    scopes:  [logAnalytics.id]
    evaluationFrequency: 'P1D'   // Check daily
    windowSize:          'P1D'
    criteria: {
      allOf: [
        {
          query: '''
            AppTraces
            | where Message has "rights-request-overdue"
            | summarize count()
          '''
          timeAggregation: 'Count'
          operator: 'GreaterThan'
          threshold: 0
          failingPeriods: { numberOfEvaluationPeriods: 1, minFailingPeriodsToAlert: 1 }
        }
      ]
    }
    actions: { actionGroups: [alertGroup.id] }
  }
}

// ── MICROSOFT SENTINEL (SIEM — DORA + DORA NIS2) ────────────
resource sentinelSolution 'Microsoft.OperationsManagement/solutions@2015-11-01-preview' = {
  name: 'SecurityInsights(log-${prefix})'
  location: location
  tags: tags
  plan: {
    name:          'SecurityInsights(log-${prefix})'
    publisher:     'Microsoft'
    product:       'OMSGallery/SecurityInsights'
    promotionCode: ''
  }
  properties: {
    workspaceResourceId: logAnalytics.id
  }
}

// ── DASHBOARD: DORA Incident Overview ───────────────────────
resource doraDashboard 'Microsoft.Portal/dashboards@2020-09-01-preview' = {
  name: 'dash-dora-${prefix}'
  location: location
  tags: union(tags, { Dashboard: 'DORA-Incidents' })
  properties: {
    lenses: []  // Configured via Azure Portal / ARM template post-deploy
    metadata: {
      model: {
        timeRange: { value: { relative: { duration: 24, timeUnit: 1 } }, type: 'MsPortalFx.Composition.Configuration.ValueTypes.TimeRange' }
      }
    }
  }
}

// ── OUTPUTS ──────────────────────────────────────────────────
output logAnalyticsId       string = logAnalytics.id
output appInsightsKey       string = appInsights.properties.InstrumentationKey
output appInsightsConnStr   string = appInsights.properties.ConnectionString
output alertGroupId         string = alertGroup.id
