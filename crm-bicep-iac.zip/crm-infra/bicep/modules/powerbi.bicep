// ============================================================
// MODULE: powerbi.bicep
// Azure Power BI Embedded Capacity (SKU A1)
// + Synapse Analytics workspace for reporting data
// ============================================================

param prefix   string
param location string
param tags     object

// ── POWER BI EMBEDDED CAPACITY ───────────────────────────────
// SKU A1 = minimum for embedded in CRM app
// Upgrade to A2+ if >10 concurrent report viewers
resource pbiCapacity 'Microsoft.PowerBIDedicated/capacities@2021-01-01' = {
  name: 'pbi${replace(prefix, '-', '')}'  // No hyphens in PBI capacity names
  location: location
  tags: tags
  sku: {
    name:     'A1'       // Start with A1 (~DKK 5.000/month), scale as needed
    tier:     'PBIE_Azure'
    capacity: 1
  }
  properties: {
    administration: {
      members: []  // Add admin UPNs: ['admin@yourdomain.dk']
    }
    mode: 'Gen2'   // Generation 2 — better performance, lower latency
  }
}

// ── SYNAPSE ANALYTICS (data warehouse for reporting) ─────────
resource synapseStorage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: replace('stsynapse${prefix}', '-', '')
  location: location
  tags: tags
  kind: 'StorageV2'
  sku: { name: 'Standard_LRS' }
  properties: {
    isHnsEnabled:               true   // Hierarchical namespace (Data Lake)
    minimumTlsVersion:          'TLS1_2'
    allowBlobPublicAccess:      false
    supportsHttpsTrafficOnly:   true
    publicNetworkAccess:        'Disabled'
  }
}

resource synapseWorkspace 'Microsoft.Synapse/workspaces@2021-06-01' = {
  name: 'syn-${prefix}'
  location: location
  tags: tags
  identity: { type: 'SystemAssigned' }
  properties: {
    defaultDataLakeStorage: {
      accountUrl: synapseStorage.properties.primaryEndpoints.dfs
      filesystem: 'synapse'
    }
    publicNetworkAccess:   'Disabled'
    managedVirtualNetwork: 'default'
    managedResourceGroupName: 'mrg-${prefix}-synapse'
  }
}

// ── SYNAPSE SQL POOL (dedicated — for Power BI DirectQuery) ──
// Comment out if starting with serverless SQL (lower cost)
// resource synapseSqlPool 'Microsoft.Synapse/workspaces/sqlPools@2021-06-01' = {
//   parent: synapseWorkspace
//   name: 'sqldw01'
//   location: location
//   sku: { name: 'DW100c', tier: 'DataWarehouse' }  // Smallest dedicated pool
//   properties: { createMode: 'Default' }
// }

// ── OUTPUTS ──────────────────────────────────────────────────
output capacityName     string = pbiCapacity.name
output capacityId       string = pbiCapacity.id
output synapseWorkspaceId string = synapseWorkspace.id
output synapseEndpoint  string = synapseWorkspace.properties.connectivityEndpoints.sql
