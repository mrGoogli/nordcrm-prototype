// ============================================================
// NordCRM — Azure Infrastructure (Bicep IaC)
// Danish Financial Sector · GDPR + DORA Compliant
// ============================================================
// Deploy:
//   az deployment sub create \
//     --location northeurope \
//     --template-file main.bicep \
//     --parameters @main.bicepparam
// ============================================================

targetScope = 'subscription'

// ── PARAMETERS ──────────────────────────────────────────────
@description('Environment: dev | staging | prod')
@allowed(['dev', 'staging', 'prod'])
param environment string = 'prod'

@description('Primary Azure region — MUST be EU for GDPR/DORA')
@allowed(['northeurope', 'westeurope'])
param primaryLocation string = 'northeurope'

@description('DR Azure region — must differ from primary')
@allowed(['northeurope', 'westeurope'])
param drLocation string = 'westeurope'

@description('Project/product name prefix')
param projectName string = 'nordcrm'

@description('Azure AD Tenant ID')
param tenantId string

@description('Entra ID Object ID of the DPO/admin group')
param adminGroupObjectId string

@description('Notification email for alerts — DORA + GDPR incidents')
param alertEmail string

@description('Stacc API base URL')
param staccApiUrl string = 'https://api.stacccloud.com/v1'

@description('Tags applied to all resources')
param tags object = {
  Project: 'NordCRM'
  Environment: environment
  DataClassification: 'Confidential-Financial'
  GDPRScope: 'true'
  DORAScope: 'true'
  Owner: 'platform-team'
  CostCenter: 'CC-CRM-001'
}

// ── VARIABLES ────────────────────────────────────────────────
var prefix    = '${projectName}-${environment}'
var shortEnv  = environment == 'prod' ? 'prd' : environment == 'staging' ? 'stg' : 'dev'
var rgName    = 'rg-${prefix}'
var rgDrName  = 'rg-${prefix}-dr'

// ── RESOURCE GROUPS ─────────────────────────────────────────
resource rg 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: rgName
  location: primaryLocation
  tags: union(tags, { Region: 'Primary', Purpose: 'CRM-Primary' })
}

resource rgDr 'Microsoft.Resources/resourceGroups@2023-07-01' = {
  name: rgDrName
  location: drLocation
  tags: union(tags, { Region: 'DR', Purpose: 'CRM-DisasterRecovery' })
}

// ── CORE INFRASTRUCTURE ──────────────────────────────────────
module core './modules/core.bicep' = {
  name: 'core-${shortEnv}'
  scope: rg
  params: {
    prefix:             prefix
    location:           primaryLocation
    drLocation:         drLocation
    tenantId:           tenantId
    adminGroupObjectId: adminGroupObjectId
    alertEmail:         alertEmail
    tags:               tags
  }
}

// ── COSMOS DB (Primary + DR) ─────────────────────────────────
module cosmos './modules/cosmos.bicep' = {
  name: 'cosmos-${shortEnv}'
  scope: rg
  params: {
    prefix:      prefix
    location:    primaryLocation
    drLocation:  drLocation
    keyVaultId:  core.outputs.keyVaultId
    tags:        tags
  }
  dependsOn: [core]
}

// ── APPLICATION LAYER ────────────────────────────────────────
module app './modules/app.bicep' = {
  name: 'app-${shortEnv}'
  scope: rg
  params: {
    prefix:          prefix
    location:        primaryLocation
    cosmosAccountId: cosmos.outputs.cosmosAccountId
    serviceBusId:    core.outputs.serviceBusId
    keyVaultId:      core.outputs.keyVaultId
    staccApiUrl:     staccApiUrl
    tags:            tags
  }
  dependsOn: [cosmos]
}

// ── OBSERVABILITY (DORA mandatory) ──────────────────────────
module observability './modules/observability.bicep' = {
  name: 'obs-${shortEnv}'
  scope: rg
  params: {
    prefix:     prefix
    location:   primaryLocation
    alertEmail: alertEmail
    tags:       tags
  }
  dependsOn: [app]
}

// ── POWER BI EMBEDDED ────────────────────────────────────────
module powerbi './modules/powerbi.bicep' = {
  name: 'pbi-${shortEnv}'
  scope: rg
  params: {
    prefix:   prefix
    location: primaryLocation
    tags:     tags
  }
}

// ── OUTPUTS ──────────────────────────────────────────────────
output resourceGroupName   string = rg.name
output drResourceGroupName string = rgDr.name
output cosmosAccountName   string = cosmos.outputs.cosmosAccountName
output apiManagementUrl    string = app.outputs.apiManagementUrl
output containerAppEnvId   string = app.outputs.containerAppEnvId
output keyVaultUri         string = core.outputs.keyVaultUri
output logAnalyticsId      string = observability.outputs.logAnalyticsId
output powerBiCapacityName string = powerbi.outputs.capacityName
