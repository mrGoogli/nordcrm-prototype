// NordCRM — Production Parameters
// main.bicepparam
using './main.bicep'

param environment          = 'prod'
param primaryLocation      = 'northeurope'
param drLocation           = 'westeurope'
param projectName          = 'nordcrm'
param tenantId             = '<YOUR-ENTRA-TENANT-ID>'
param adminGroupObjectId   = '<YOUR-ADMIN-GROUP-OBJECT-ID>'
param alertEmail           = 'dpo@yourdomain.dk'
param staccApiUrl          = 'https://api.stacccloud.com/v1'
